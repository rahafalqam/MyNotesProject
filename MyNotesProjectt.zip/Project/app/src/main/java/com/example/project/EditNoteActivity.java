package com.example.project;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditNoteActivity extends AppCompatActivity {

    EditText etEditTitle;
    EditText etEditContent;
    EditText etEditTags;

    Button btnUpdateNote;

    DatabaseHelper databaseHelper;
    SharedPrefManager sharedPrefManager;

    private static final String KEY_CURRENT_EMAIL =
            "currentEmail";

    private int noteId;
    private String creationDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_edit_note
        );

        etEditTitle =
                findViewById(R.id.etEditTitle);

        etEditContent =
                findViewById(R.id.etEditContent);

        etEditTags =
                findViewById(R.id.etEditTags);

        btnUpdateNote =
                findViewById(R.id.btnUpdateNote);

        databaseHelper =
                new DatabaseHelper(this);

        sharedPrefManager =
                SharedPrefManager.getInstance(this);

        noteId =
                getIntent().getIntExtra(
                        "note_id",
                        -1
                );

        if (noteId == -1) {

            Toast.makeText(
                    this,
                    "Note not found",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }

        loadNote();

        btnUpdateNote.setOnClickListener(
                v -> updateNote()
        );
    }

    private void loadNote() {

        String email =
                sharedPrefManager.readString(
                        KEY_CURRENT_EMAIL,
                        ""
                );

        if (email.isEmpty()) {

            Toast.makeText(
                    this,
                    "User email not found",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }

        Cursor cursor =
                databaseHelper.getNote(
                        noteId,
                        email
                );

        if (cursor != null &&
                cursor.moveToFirst()) {

            String title =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    DatabaseHelper.COL_NOTE_TITLE
                            )
                    );

            String content =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    DatabaseHelper.COL_NOTE_CONTENT
                            )
                    );

            String tags =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    DatabaseHelper.COL_NOTE_TAGS
                            )
                    );

            creationDate =
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    DatabaseHelper.COL_NOTE_DATE
                            )
                    );

            etEditTitle.setText(title);
            etEditContent.setText(content);
            etEditTags.setText(tags);

        } else {

            Toast.makeText(
                    this,
                    "Note not found",
                    Toast.LENGTH_SHORT
            ).show();

            finish();
        }

        if (cursor != null) {
            cursor.close();
        }
    }

    private void updateNote() {

        String title =
                etEditTitle.getText()
                        .toString()
                        .trim();

        String content =
                etEditContent.getText()
                        .toString()
                        .trim();

        String tags =
                etEditTags.getText()
                        .toString()
                        .trim();

        if (title.isEmpty()) {

            etEditTitle.setError(
                    "Title is required"
            );

            etEditTitle.requestFocus();

            return;
        }

        if (content.isEmpty()) {

            etEditContent.setError(
                    "Content is required"
            );

            etEditContent.requestFocus();

            return;
        }

        String email =
                sharedPrefManager.readString(
                        KEY_CURRENT_EMAIL,
                        ""
                );

        if (email.isEmpty()) {

            Toast.makeText(
                    this,
                    "User email not found",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        boolean result =
                databaseHelper.updateNote(
                        noteId,
                        email,
                        title,
                        content,
                        creationDate,
                        tags
                );

        if (result) {

            Toast.makeText(
                    this,
                    "Note updated successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Failed to update note",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}