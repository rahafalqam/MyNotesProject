package com.example.project;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {

    private static final String SHARED_PREF_NAME = "MyNotesPrefs";
    private static final int SHARED_PREF_PRIVATE = Context.MODE_PRIVATE;

    private static SharedPrefManager ourInstance = null;

    private final SharedPreferences sharedPreferences;
    private final SharedPreferences.Editor editor;

    private SharedPrefManager(Context context) {

        sharedPreferences = context.getApplicationContext()
                .getSharedPreferences(
                        SHARED_PREF_NAME,
                        SHARED_PREF_PRIVATE
                );

        editor = sharedPreferences.edit();
    }

    public static SharedPrefManager getInstance(Context context) {

        if (ourInstance != null) {
            return ourInstance;
        }

        ourInstance = new SharedPrefManager(context);
        return ourInstance;
    }

    public boolean writeString(String key, String value) {
        editor.putString(key, value);
        return editor.commit();
    }

    public String readString(String key, String defaultValue) {
        return sharedPreferences.getString(key, defaultValue);
    }

    public boolean removeString(String key) {
        editor.remove(key);
        return editor.commit();
    }
}