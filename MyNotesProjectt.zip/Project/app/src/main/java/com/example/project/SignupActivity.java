package com.example.project;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {

    EditText etEmail, etFirstName, etLastName;
    EditText etPassword, etConfirmPassword;

    Button btnSignUp;
    TextView tvSignIn;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Connect XML components
        etEmail = findViewById(R.id.etEmail);
        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);

        btnSignUp = findViewById(R.id.btnSignUp);
        tvSignIn = findViewById(R.id.tvSignIn);

        // Database
        databaseHelper = new DatabaseHelper(this);

        // Sign Up button
        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

        // Go back to Sign In
        tvSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void registerUser() {

        String email = etEmail.getText().toString().trim();
        String firstName = etFirstName.getText().toString().trim();
        String lastName = etLastName.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirmPassword = etConfirmPassword.getText().toString();


        // Email validation
        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter a valid email");
            etEmail.requestFocus();
            return;
        }


        // First name validation
        if (firstName.length() < 3 || firstName.length() > 10) {
            etFirstName.setError("3-10 characters required");
            etFirstName.requestFocus();
            return;
        }


        // Last name validation
        if (lastName.length() < 3 || lastName.length() > 10) {
            etLastName.setError("3-10 characters required");
            etLastName.requestFocus();
            return;
        }


        // Password length
        if (password.length() < 6 || password.length() > 12) {
            etPassword.setError("Password must be 6-12 characters");
            etPassword.requestFocus();
            return;
        }


        // Password contains number
        if (!password.matches(".*[0-9].*")) {
            etPassword.setError("Password must contain a number");
            etPassword.requestFocus();
            return;
        }


        // Password contains lowercase
        if (!password.matches(".*[a-z].*")) {
            etPassword.setError("Password must contain lowercase letter");
            etPassword.requestFocus();
            return;
        }


        // Password contains uppercase
        if (!password.matches(".*[A-Z].*")) {
            etPassword.setError("Password must contain uppercase letter");
            etPassword.requestFocus();
            return;
        }


        // Confirm password
        if (!password.equals(confirmPassword)) {
            etConfirmPassword.setError("Passwords do not match");
            etConfirmPassword.requestFocus();
            return;
        }


        // Check duplicate email
        if (databaseHelper.emailExists(email)) {
            etEmail.setError("Email already registered");
            etEmail.requestFocus();
            return;
        }


        // Insert user into database
        boolean success = databaseHelper.insertUser(
                email,
                firstName,
                lastName,
                password
        );


        if (success) {

            Toast.makeText(
                    this,
                    "Account created successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Registration failed",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}