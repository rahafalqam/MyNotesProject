package com.example.project;

public class Note {
    private int id;
    private String userEmail;
    private String title;
    private String content;
    private String creationDate;
    private boolean favorite;
    private String tags;

    public Note(int id, String userEmail, String title, String content,
                String creationDate, boolean favorite, String tags) {
        this.id = id;
        this.userEmail = userEmail;
        this.title = title;
        this.content = content;
        this.creationDate = creationDate;
        this.favorite = favorite;
        this.tags = tags == null ? "" : tags;
    }

    public int getId() { return id; }
    public String getUserEmail() { return userEmail; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getCreationDate() { return creationDate; }
    public boolean isFavorite() { return favorite; }
    public String getTags() { return tags; }
    public void setFavorite(boolean favorite) { this.favorite = favorite; }
}
