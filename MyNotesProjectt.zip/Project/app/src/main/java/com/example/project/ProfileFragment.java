package com.example.project;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private static final String KEY_CURRENT_EMAIL =
            "currentEmail";

    private DatabaseHelper databaseHelper;
    private SharedPrefManager sharedPrefManager;

    private EditText etFirstName;
    private EditText etLastName;
    private EditText etEmail;
    private EditText etPassword;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_profile,
                container,
                false
        );

        databaseHelper =
                new DatabaseHelper(requireContext());

        sharedPrefManager =
                SharedPrefManager.getInstance(
                        requireContext()
                );

        etFirstName =
                view.findViewById(
                        R.id.etProfileFirstName
                );

        etLastName =
                view.findViewById(
                        R.id.etProfileLastName
                );

        etEmail =
                view.findViewById(
                        R.id.etProfileEmail
                );

        etPassword =
                view.findViewById(
                        R.id.etProfilePassword
                );

        Button btnUpdate =
                view.findViewById(
                        R.id.btnUpdateProfile
                );

        Button btnLogout =
                view.findViewById(
                        R.id.btnLogout
                );

        btnUpdate.setOnClickListener(
                v -> updateProfile()
        );

        btnLogout.setOnClickListener(
                v -> logout()
        );

        loadProfile();

        return view;
    }

    private String getCurrentEmail() {

        return sharedPrefManager.readString(
                KEY_CURRENT_EMAIL,
                ""
        );
    }

    private void loadProfile() {

        String email =
                getCurrentEmail();

        if (email.isEmpty()) {
            return;
        }

        Cursor cursor =
                databaseHelper.getUser(email);

        if (cursor != null) {

            try {

                if (cursor.moveToFirst()) {

                    etEmail.setText(
                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_EMAIL
                                    )
                            )
                    );

                    etFirstName.setText(
                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_FIRST_NAME
                                    )
                            )
                    );

                    etLastName.setText(
                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_LAST_NAME
                                    )
                            )
                    );
                }

            } finally {

                cursor.close();
            }
        }
    }

    private void updateProfile() {

        String email =
                getCurrentEmail();

        String firstName =
                etFirstName.getText()
                        .toString()
                        .trim();

        String lastName =
                etLastName.getText()
                        .toString()
                        .trim();

        String password =
                etPassword.getText()
                        .toString();

        if (firstName.length() < 3 ||
                firstName.length() > 10) {

            etFirstName.setError(
                    "3-10 characters required"
            );

            return;
        }

        if (lastName.length() < 3 ||
                lastName.length() > 10) {

            etLastName.setError(
                    "3-10 characters required"
            );

            return;
        }

        if (password.isEmpty()) {

            Cursor cursor =
                    databaseHelper.getUser(email);

            if (cursor != null) {

                try {

                    if (cursor.moveToFirst()) {

                        password =
                                cursor.getString(
                                        cursor.getColumnIndexOrThrow(
                                                DatabaseHelper.COL_PASSWORD
                                        )
                                );
                    }

                } finally {

                    cursor.close();
                }
            }
        }

        if (databaseHelper.updateUser(
                email,
                firstName,
                lastName,
                password
        )) {

            Toast.makeText(
                    requireContext(),
                    "Profile updated",
                    Toast.LENGTH_SHORT
            ).show();

            etPassword.setText("");

        } else {

            Toast.makeText(
                    requireContext(),
                    "Profile update failed",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void logout() {

        sharedPrefManager.removeString(
                KEY_CURRENT_EMAIL
        );

        Intent intent =
                new Intent(
                        requireContext(),
                        LoginActivity.class
                );

        intent.addFlags(
                Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_NEW_TASK
        );

        startActivity(intent);

        requireActivity().finishAffinity();
    }
}