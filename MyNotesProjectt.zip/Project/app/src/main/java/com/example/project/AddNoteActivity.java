package com.example.project;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddNoteActivity extends AppCompatActivity {

    EditText etNoteTitle;
    EditText etNoteContent;
    EditText etNoteTags;

    Button btnSaveNote;

    DatabaseHelper databaseHelper;
    SharedPrefManager sharedPrefManager;

    private static final String KEY_CURRENT_EMAIL =
            "currentEmail";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_add_note
        );

        etNoteTitle =
                findViewById(R.id.etNoteTitle);

        etNoteContent =
                findViewById(R.id.etNoteContent);

        etNoteTags =
                findViewById(R.id.etNoteTags);

        btnSaveNote =
                findViewById(R.id.btnSaveNote);

        databaseHelper =
                new DatabaseHelper(this);

        sharedPrefManager =
                SharedPrefManager.getInstance(this);

        btnSaveNote.setOnClickListener(
                v -> saveNote()
        );
    }

    private void saveNote() {

        String title =
                etNoteTitle.getText()
                        .toString()
                        .trim();

        String content =
                etNoteContent.getText()
                        .toString()
                        .trim();

        String tags =
                etNoteTags.getText()
                        .toString()
                        .trim();

        if (title.isEmpty()) {

            etNoteTitle.setError(
                    "Title is required"
            );

            etNoteTitle.requestFocus();

            return;
        }

        if (content.isEmpty()) {

            etNoteContent.setError(
                    "Content is required"
            );

            etNoteContent.requestFocus();

            return;
        }

        String email =
                sharedPrefManager.readString(
                        KEY_CURRENT_EMAIL,
                        ""
                );

        if (email.isEmpty()) {

            Toast.makeText(
                    this,
                    "User email not found",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String creationDate =
                new java.text.SimpleDateFormat(
                        "yyyy-MM-dd HH:mm:ss",
                        java.util.Locale.getDefault()
                ).format(
                        new java.util.Date()
                );

        long result =
                databaseHelper.insertNote(
                        email,
                        title,
                        content,
                        creationDate,
                        tags
                );

        if (result != -1) {

            Toast.makeText(
                    this,
                    "Note saved successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Failed to save note",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}