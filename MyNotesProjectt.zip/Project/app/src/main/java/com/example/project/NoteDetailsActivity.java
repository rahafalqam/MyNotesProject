package com.example.project;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class NoteDetailsActivity extends AppCompatActivity {

    private static final String KEY_CURRENT_EMAIL =
            "currentEmail";

    private DatabaseHelper databaseHelper;
    private SharedPrefManager sharedPrefManager;

    private int noteId;

    private TextView tvNoteTitle;
    private TextView tvNoteContent;
    private TextView tvNoteDate;
    private TextView tvNoteTags;

    private ImageButton btnFavorite;

    private Button btnEditNote;
    private Button btnDeleteNote;
    private Button btnSendEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(
                R.layout.activity_note_details
        );

        Toolbar toolbar =
                findViewById(R.id.detailsToolbar);

        setSupportActionBar(toolbar);

        if (getSupportActionBar() != null) {

            getSupportActionBar()
                    .setDisplayHomeAsUpEnabled(true);
        }

        toolbar.setNavigationOnClickListener(
                v -> finish()
        );

        tvNoteTitle =
                findViewById(R.id.tvDetailTitle);

        tvNoteContent =
                findViewById(R.id.tvDetailContent);

        tvNoteDate =
                findViewById(R.id.tvDetailDate);

        tvNoteTags =
                findViewById(R.id.tvDetailTags);

        btnFavorite =
                findViewById(R.id.btnDetailFavorite);

        btnEditNote =
                findViewById(R.id.btnEditNote);

        btnDeleteNote =
                findViewById(R.id.btnDeleteNote);

        btnSendEmail =
                findViewById(R.id.btnSendEmail);

        databaseHelper =
                new DatabaseHelper(this);

        sharedPrefManager =
                SharedPrefManager.getInstance(this);

        noteId =
                getIntent().getIntExtra(
                        "note_id",
                        -1
                );

        if (noteId == -1) {

            Toast.makeText(
                    this,
                    "Note not found",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }

        loadNote();

        btnEditNote.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            this,
                            EditNoteActivity.class
                    );

            intent.putExtra(
                    "note_id",
                    noteId
            );

            startActivity(intent);
        });

        btnDeleteNote.setOnClickListener(
                v -> showDeleteConfirmation()
        );

        btnFavorite.setOnClickListener(
                v -> toggleFavorite()
        );

        btnSendEmail.setOnClickListener(
                v -> sendEmail()
        );
    }

    @Override
    protected void onResume() {

        super.onResume();

        if (databaseHelper != null &&
                noteId != -1) {

            loadNote();
        }
    }

    private String getCurrentEmail() {

        return sharedPrefManager.readString(
                KEY_CURRENT_EMAIL,
                ""
        );
    }

    private void loadNote() {

        String email =
                getCurrentEmail();

        if (email.isEmpty()) {

            Toast.makeText(
                    this,
                    "User session not found",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

            return;
        }

        Cursor cursor =
                databaseHelper.getNote(
                        noteId,
                        email
                );

        if (cursor != null) {

            try {

                if (cursor.moveToFirst()) {

                    tvNoteTitle.setText(
                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_TITLE
                                    )
                            )
                    );

                    tvNoteContent.setText(
                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_CONTENT
                                    )
                            )
                    );

                    tvNoteDate.setText(
                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_DATE
                                    )
                            )
                    );

                    String tags =
                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_TAGS
                                    )
                            );

                    tvNoteTags.setText(
                            tags == null ||
                                    tags.isEmpty()
                                    ? "No tags"
                                    : tags
                    );

                    boolean favorite =
                            cursor.getInt(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_FAVORITE
                                    )
                            ) == 1;

                    btnFavorite.setImageResource(
                            favorite
                                    ? android.R.drawable.btn_star_big_on
                                    : android.R.drawable.btn_star_big_off
                    );

                } else {

                    Toast.makeText(
                            this,
                            "Note not found",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();
                }

            } finally {

                cursor.close();
            }
        }
    }

    private void toggleFavorite() {

        String email =
                getCurrentEmail();

        Cursor cursor =
                databaseHelper.getNote(
                        noteId,
                        email
                );

        if (cursor == null) {
            return;
        }

        try {

            if (cursor.moveToFirst()) {

                boolean current =
                        cursor.getInt(
                                cursor.getColumnIndexOrThrow(
                                        DatabaseHelper.COL_NOTE_FAVORITE
                                )
                        ) == 1;

                if (databaseHelper.setFavorite(
                        noteId,
                        email,
                        !current
                )) {

                    loadNote();

                    Toast.makeText(
                            this,
                            !current
                                    ? "Added to favorites"
                                    : "Removed from favorites",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            }

        } finally {

            cursor.close();
        }
    }

    private void showDeleteConfirmation() {

        new androidx.appcompat.app.AlertDialog.Builder(this)

                .setTitle("Delete Note")

                .setMessage(
                        "Are you sure you want to delete this note?"
                )

                .setPositiveButton(
                        "Delete",
                        (dialog, which) ->
                                deleteNote()
                )

                .setNegativeButton(
                        "Cancel",
                        null
                )

                .show();
    }

    private void deleteNote() {

        String email =
                getCurrentEmail();

        if (databaseHelper.deleteNote(
                noteId,
                email
        )) {

            Toast.makeText(
                    this,
                    "Note deleted successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            finish();

        } else {

            Toast.makeText(
                    this,
                    "Failed to delete note",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void sendEmail() {

        String subject =
                tvNoteTitle.getText()
                        .toString();

        String body =
                tvNoteContent.getText()
                        .toString();

        Intent gmailIntent = new Intent();

        gmailIntent.setAction(Intent.ACTION_SENDTO);

        gmailIntent.setType("message/rfc822");

        gmailIntent.setData(Uri.parse("mailto:"));

        gmailIntent.putExtra(
                Intent.EXTRA_SUBJECT,
                subject
        );

        gmailIntent.putExtra(
                Intent.EXTRA_TEXT,
                body
        );

        try {
            startActivity(gmailIntent);
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "No email application found",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}