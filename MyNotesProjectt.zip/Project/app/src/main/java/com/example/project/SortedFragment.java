package com.example.project;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class
SortedFragment extends Fragment {

    private static final String KEY_CURRENT_EMAIL = "currentEmail";
    private static final String KEY_SORT = "sortPreference";

    private DatabaseHelper databaseHelper;
    private SharedPrefManager sharedPrefManager;

    private final List<Note> notes = new ArrayList<>();

    private NoteAdapter adapter;

    private String userEmail;

    private RadioGroup sortGroup;
    private EditText etTag;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_sorted,
                container,
                false
        );

        // Database
        databaseHelper = new DatabaseHelper(requireContext());

        // Shared Preferences Manager
        sharedPrefManager =
                SharedPrefManager.getInstance(requireContext());

        // Get current user
        userEmail = sharedPrefManager.readString(
                KEY_CURRENT_EMAIL,
                ""
        );

        // Connect views
        sortGroup = view.findViewById(R.id.sortGroup);
        etTag = view.findViewById(R.id.etTagFilter);

        RecyclerView recycler =
                view.findViewById(R.id.recyclerSortedNotes);

        recycler.setLayoutManager(
                new LinearLayoutManager(requireContext())
        );

        adapter = new NoteAdapter(
                notes,
                this::toggleFavorite
        );

        recycler.setAdapter(adapter);

        // Load saved sorting choice
        String savedSort =
                sharedPrefManager.readString(
                        KEY_SORT,
                        "date"
                );

        if (savedSort.equals("alpha")) {

            sortGroup.check(R.id.rbAlphabetical);

        } else {

            sortGroup.check(R.id.rbDate);
        }

        // Sorting
        sortGroup.setOnCheckedChangeListener(
                (group, checkedId) -> {

                    String value;

                    if (checkedId == R.id.rbAlphabetical) {
                        value = "alpha";
                    } else {
                        value = "date";
                    }

                    sharedPrefManager.writeString(
                            KEY_SORT,
                            value
                    );

                    loadNotes();
                }
        );

        // Apply tag filter
        view.findViewById(R.id.btnApplyTag)
                .setOnClickListener(v -> loadNotes());

        loadNotes();

        return view;
    }

    private void loadNotes() {

        if (userEmail == null || userEmail.isEmpty()) {
            return;
        }

        String tag =
                etTag.getText().toString().trim();

        String sort =
                sharedPrefManager.readString(
                        KEY_SORT,
                        "date"
                );

        Cursor cursor;

        if (!tag.isEmpty()) {

            cursor = databaseHelper.getNotesByTag(
                    userEmail,
                    tag
            );

        } else if (sort.equals("alpha")) {

            cursor =
                    databaseHelper.getNotesSortedAlphabetically(
                            userEmail
                    );

        } else {

            cursor =
                    databaseHelper.getNotesSortedByDate(
                            userEmail
                    );
        }

        notes.clear();

        if (cursor != null) {

            try {

                while (cursor.moveToNext()) {

                    notes.add(new Note(
                            cursor.getInt(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_ID
                                    )
                            ),

                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_USER_EMAIL
                                    )
                            ),

                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_TITLE
                                    )
                            ),

                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_CONTENT
                                    )
                            ),

                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_DATE
                                    )
                            ),

                            cursor.getInt(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_FAVORITE
                                    )
                            ) == 1,

                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            DatabaseHelper.COL_NOTE_TAGS
                                    )
                            )
                    ));
                }

            } finally {

                cursor.close();
            }
        }

        adapter.notifyDataSetChanged();
    }

    private void toggleFavorite(
            Note note,
            int position) {

        boolean newValue =
                !note.isFavorite();

        if (databaseHelper.setFavorite(
                note.getId(),
                userEmail,
                newValue
        )) {

            note.setFavorite(newValue);

            adapter.notifyItemChanged(position);

            Toast.makeText(
                    requireContext(),
                    newValue
                            ? "Added to favorites"
                            : "Removed from favorites",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}