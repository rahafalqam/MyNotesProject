package com.example.project;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class AllNotesFragment extends Fragment {

    private static final String KEY_CURRENT_EMAIL = "currentEmail";

    private DatabaseHelper databaseHelper;
    private SharedPrefManager sharedPrefManager;

    private RecyclerView recyclerNotes;
    private NoteAdapter noteAdapter;

    private final List<Note> notes = new ArrayList<>();

    private String userEmail;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_all_notes,
                container,
                false
        );

        databaseHelper =
                new DatabaseHelper(requireContext());

        sharedPrefManager =
                SharedPrefManager.getInstance(requireContext());

        userEmail =
                sharedPrefManager.readString(
                        KEY_CURRENT_EMAIL,
                        ""
                );

        recyclerNotes =
                view.findViewById(R.id.recyclerNotes);

        recyclerNotes.setLayoutManager(
                new LinearLayoutManager(requireContext())
        );

        noteAdapter =
                new NoteAdapter(
                        notes,
                        this::toggleFavorite
                );

        recyclerNotes.setAdapter(noteAdapter);

        android.widget.EditText search =
                view.findViewById(R.id.etSearch);

        search.addTextChangedListener(
                new TextWatcher() {

                    @Override
                    public void beforeTextChanged(
                            CharSequence s,
                            int start,
                            int count,
                            int after) {
                    }

                    @Override
                    public void onTextChanged(
                            CharSequence s,
                            int start,
                            int before,
                            int count) {

                        loadNotes(
                                s.toString().trim()
                        );
                    }

                    @Override
                    public void afterTextChanged(
                            Editable s) {
                    }
                }
        );

        FloatingActionButton addButton =
                view.findViewById(R.id.fabAddNote);

        addButton.setOnClickListener(v ->
                startActivity(
                        new Intent(
                                requireContext(),
                                AddNoteActivity.class
                        )
                )
        );

        return view;
    }

    @Override
    public void onResume() {

        super.onResume();

        if (databaseHelper != null) {
            loadNotes("");
        }
    }

    private void loadNotes(String search) {

        if (userEmail == null ||
                userEmail.isEmpty()) {
            return;
        }

        Cursor cursor;

        if (search.isEmpty()) {

            cursor =
                    databaseHelper.getAllNotes(
                            userEmail
                    );

        } else {

            cursor =
                    databaseHelper.searchNotes(
                            userEmail,
                            search
                    );
        }

        notes.clear();

        readCursor(cursor);

        noteAdapter.notifyDataSetChanged();
    }

    private void readCursor(Cursor cursor) {

        if (cursor == null) {
            return;
        }

        try {

            while (cursor.moveToNext()) {

                notes.add(
                        noteFromCursor(cursor)
                );
            }

        } finally {

            cursor.close();
        }
    }

    private Note noteFromCursor(Cursor c) {

        return new Note(

                c.getInt(
                        c.getColumnIndexOrThrow(
                                DatabaseHelper.COL_NOTE_ID
                        )
                ),

                c.getString(
                        c.getColumnIndexOrThrow(
                                DatabaseHelper.COL_NOTE_USER_EMAIL
                        )
                ),

                c.getString(
                        c.getColumnIndexOrThrow(
                                DatabaseHelper.COL_NOTE_TITLE
                        )
                ),

                c.getString(
                        c.getColumnIndexOrThrow(
                                DatabaseHelper.COL_NOTE_CONTENT
                        )
                ),

                c.getString(
                        c.getColumnIndexOrThrow(
                                DatabaseHelper.COL_NOTE_DATE
                        )
                ),

                c.getInt(
                        c.getColumnIndexOrThrow(
                                DatabaseHelper.COL_NOTE_FAVORITE
                        )
                ) == 1,

                c.getString(
                        c.getColumnIndexOrThrow(
                                DatabaseHelper.COL_NOTE_TAGS
                        )
                )
        );
    }

    private void toggleFavorite(
            Note note,
            int position) {

        boolean newValue =
                !note.isFavorite();

        if (databaseHelper.setFavorite(
                note.getId(),
                userEmail,
                newValue
        )) {

            note.setFavorite(newValue);

            noteAdapter.notifyItemChanged(
                    position
            );

            Toast.makeText(
                    requireContext(),
                    newValue
                            ? "Added to favorites"
                            : "Removed from favorites",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}