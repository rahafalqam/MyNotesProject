package com.example.project;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database
    private static final String DATABASE_NAME = "MyNotes.db";
    private static final int DATABASE_VERSION = 1;

    // =========================
    // USERS TABLE
    // =========================

    public static final String TABLE_USERS = "users";

    public static final String COL_EMAIL = "email";
    public static final String COL_FIRST_NAME = "first_name";
    public static final String COL_LAST_NAME = "last_name";
    public static final String COL_PASSWORD = "password";


    // =========================
    // NOTES TABLE
    // =========================

    public static final String TABLE_NOTES = "notes";

    public static final String COL_NOTE_ID = "id";
    public static final String COL_NOTE_USER_EMAIL = "user_email";
    public static final String COL_NOTE_TITLE = "title";
    public static final String COL_NOTE_CONTENT = "content";
    public static final String COL_NOTE_DATE = "creation_date";
    public static final String COL_NOTE_FAVORITE = "is_favorite";
    public static final String COL_NOTE_TAGS = "tags";


    // =========================
    // CONSTRUCTOR
    // =========================

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    // =========================
    // CREATE DATABASE
    // =========================

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_EMAIL + " TEXT PRIMARY KEY, " +
                COL_FIRST_NAME + " TEXT NOT NULL, " +
                COL_LAST_NAME + " TEXT NOT NULL, " +
                COL_PASSWORD + " TEXT NOT NULL" +
                ")";

        db.execSQL(createUsersTable);


        // Notes table
        String createNotesTable = "CREATE TABLE " + TABLE_NOTES + " (" +
                COL_NOTE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NOTE_USER_EMAIL + " TEXT NOT NULL, " +
                COL_NOTE_TITLE + " TEXT NOT NULL, " +
                COL_NOTE_CONTENT + " TEXT NOT NULL, " +
                COL_NOTE_DATE + " TEXT NOT NULL, " +
                COL_NOTE_FAVORITE + " INTEGER DEFAULT 0, " +
                COL_NOTE_TAGS + " TEXT, " +
                "FOREIGN KEY(" + COL_NOTE_USER_EMAIL + ") REFERENCES " +
                TABLE_USERS + "(" + COL_EMAIL + ")" +
                ")";

        db.execSQL(createNotesTable);
    }


    // =========================
    // DATABASE UPGRADE
    // =========================

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

        onCreate(db);
    }


    // =====================================================
    // USER FUNCTIONS
    // =====================================================

    // Add a new user
    public boolean insertUser(String email,
                              String firstName,
                              String lastName,
                              String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_EMAIL, email);
        values.put(COL_FIRST_NAME, firstName);
        values.put(COL_LAST_NAME, lastName);
        values.put(COL_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);

        return result != -1;
    }


    // Check if email already exists
    public boolean emailExists(String email) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_EMAIL},
                COL_EMAIL + "=?",
                new String[]{email},
                null,
                null,
                null
        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();

        return exists;
    }


    // Check login
    public boolean checkLogin(String email, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_EMAIL},
                COL_EMAIL + "=? AND " + COL_PASSWORD + "=?",
                new String[]{email, password},
                null,
                null,
                null
        );

        boolean valid = cursor.getCount() > 0;

        cursor.close();

        return valid;
    }


    // Get user information
    public Cursor getUser(String email) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_USERS,
                null,
                COL_EMAIL + "=?",
                new String[]{email},
                null,
                null,
                null
        );
    }


    // Update user profile
    public boolean updateUser(String email,
                              String firstName,
                              String lastName,
                              String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_FIRST_NAME, firstName);
        values.put(COL_LAST_NAME, lastName);
        values.put(COL_PASSWORD, password);

        int result = db.update(
                TABLE_USERS,
                values,
                COL_EMAIL + "=?",
                new String[]{email}
        );

        return result > 0;
    }


    // =====================================================
    // NOTE FUNCTIONS
    // =====================================================

    // Add a new note
    public long insertNote(String userEmail,
                           String title,
                           String content,
                           String creationDate,
                           String tags) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_NOTE_USER_EMAIL, userEmail);
        values.put(COL_NOTE_TITLE, title);
        values.put(COL_NOTE_CONTENT, content);
        values.put(COL_NOTE_DATE, creationDate);
        values.put(COL_NOTE_FAVORITE, 0);
        values.put(COL_NOTE_TAGS, tags);

        return db.insert(TABLE_NOTES, null, values);
    }


    // Get all notes for a specific user
    public Cursor getAllNotes(String userEmail) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_NOTES,
                null,
                COL_NOTE_USER_EMAIL + "=?",
                new String[]{userEmail},
                null,
                null,
                COL_NOTE_ID + " DESC"
        );
    }


    // Get one note
    public Cursor getNote(int noteId, String userEmail) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_NOTES,
                null,
                COL_NOTE_ID + "=? AND " + COL_NOTE_USER_EMAIL + "=?",
                new String[]{
                        String.valueOf(noteId),
                        userEmail
                },
                null,
                null,
                null
        );
    }


    // Update note
    public boolean updateNote(int noteId,
                              String userEmail,
                              String title,
                              String content,
                              String creationDate,
                              String tags) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_NOTE_TITLE, title);
        values.put(COL_NOTE_CONTENT, content);
        values.put(COL_NOTE_DATE, creationDate);
        values.put(COL_NOTE_TAGS, tags);

        int result = db.update(
                TABLE_NOTES,
                values,
                COL_NOTE_ID + "=? AND " + COL_NOTE_USER_EMAIL + "=?",
                new String[]{
                        String.valueOf(noteId),
                        userEmail
                }
        );

        return result > 0;
    }


    // Delete note
    public boolean deleteNote(int noteId, String userEmail) {

        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(
                TABLE_NOTES,
                COL_NOTE_ID + "=? AND " + COL_NOTE_USER_EMAIL + "=?",
                new String[]{
                        String.valueOf(noteId),
                        userEmail
                }
        );

        return result > 0;
    }


    // =====================================================
    // FAVORITES
    // =====================================================

    // Change favorite status
    public boolean setFavorite(int noteId,
                               String userEmail,
                               boolean favorite) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COL_NOTE_FAVORITE, favorite ? 1 : 0);

        int result = db.update(
                TABLE_NOTES,
                values,
                COL_NOTE_ID + "=? AND " + COL_NOTE_USER_EMAIL + "=?",
                new String[]{
                        String.valueOf(noteId),
                        userEmail
                }
        );

        return result > 0;
    }


    // Get favorite notes
    public Cursor getFavoriteNotes(String userEmail) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_NOTES,
                null,
                COL_NOTE_USER_EMAIL + "=? AND " +
                        COL_NOTE_FAVORITE + "=?",
                new String[]{
                        userEmail,
                        "1"
                },
                null,
                null,
                COL_NOTE_ID + " DESC"
        );
    }


    // =====================================================
    // SEARCH
    // =====================================================

    // Search by title OR content
    public Cursor searchNotes(String userEmail, String searchText) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_NOTES,
                null,
                COL_NOTE_USER_EMAIL + "=? AND (" +
                        COL_NOTE_TITLE + " LIKE ? OR " +
                        COL_NOTE_CONTENT + " LIKE ?)",
                new String[]{
                        userEmail,
                        "%" + searchText + "%",
                        "%" + searchText + "%"
                },
                null,
                null,
                COL_NOTE_ID + " DESC"
        );
    }


    // =====================================================
    // SORTING
    // =====================================================

    // Sort by creation date
    public Cursor getNotesSortedByDate(String userEmail) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_NOTES,
                null,
                COL_NOTE_USER_EMAIL + "=?",
                new String[]{userEmail},
                null,
                null,
                COL_NOTE_DATE + " DESC"
        );
    }


    // Sort alphabetically by title
    public Cursor getNotesSortedAlphabetically(String userEmail) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_NOTES,
                null,
                COL_NOTE_USER_EMAIL + "=?",
                new String[]{userEmail},
                null,
                null,
                COL_NOTE_TITLE + " ASC"
        );
    }


    // =====================================================
    // TAG SEARCH / FILTER
    // =====================================================

    // Get notes containing a specific tag
    public Cursor getNotesByTag(String userEmail, String tag) {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.query(
                TABLE_NOTES,
                null,
                COL_NOTE_USER_EMAIL + "=? AND " +
                        COL_NOTE_TAGS + " LIKE ?",
                new String[]{
                        userEmail,
                        "%" + tag + "%"
                },
                null,
                null,
                COL_NOTE_ID + " DESC"
        );
    }
}

