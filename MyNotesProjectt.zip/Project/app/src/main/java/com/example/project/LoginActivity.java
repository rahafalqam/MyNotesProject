package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText etEmail, etPassword;
    CheckBox cbRememberMe;
    Button btnSignIn;
    TextView tvSignUp;

    DatabaseHelper databaseHelper;
    SharedPrefManager sharedPrefManager;

    private static final String KEY_EMAIL = "savedEmail";
    private static final String KEY_CURRENT_EMAIL = "currentEmail";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        // Connect XML components
        etEmail = findViewById(R.id.etLoginEmail);
        etPassword = findViewById(R.id.etLoginPassword);
        cbRememberMe = findViewById(R.id.cbRememberMe);
        btnSignIn = findViewById(R.id.btnSignIn);
        tvSignUp = findViewById(R.id.tvSignUp);


        // Database
        databaseHelper = new DatabaseHelper(this);


        // Shared Preferences Manager
        sharedPrefManager = SharedPrefManager.getInstance(this);


        // Load saved email
        String savedEmail = sharedPrefManager.readString(KEY_EMAIL, "");

        if (!savedEmail.isEmpty()) {
            etEmail.setText(savedEmail);
            cbRememberMe.setChecked(true);
        }


        // Sign In button
        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });


        // Open Sign Up
        tvSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(
                        LoginActivity.this,
                        SignupActivity.class
                );

                startActivity(intent);
            }
        });

    }


    private void loginUser() {

        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();


        // Empty email
        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return;
        }


        // Email format
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Enter a valid email");
            etEmail.requestFocus();
            return;
        }


        // Empty password
        if (password.isEmpty()) {
            etPassword.setError("Password is required");
            etPassword.requestFocus();
            return;
        }


        // Check database
        boolean valid = databaseHelper.checkLogin(
                email,
                password
        );


        if (valid) {


            // Save current logged-in user
            sharedPrefManager.writeString(
                    KEY_CURRENT_EMAIL,
                    email
            );


            // Remember Me
            if (cbRememberMe.isChecked()) {

                sharedPrefManager.writeString(
                        KEY_EMAIL,
                        email
                );

            } else {

                sharedPrefManager.removeString(KEY_EMAIL);
            }


            Toast.makeText(
                    this,
                    "Login successful!",
                    Toast.LENGTH_SHORT
            ).show();


            // Open MainActivity
            Intent intent = new Intent(
                    LoginActivity.this,
                    MainActivity.class
            );

            startActivity(intent);
            finish();


        } else {


            Toast.makeText(
                    this,
                    "Invalid email or password",
                    Toast.LENGTH_SHORT
            ).show();

        }

    }
}