package com.example.project;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class FavoritesFragment extends Fragment {

    private static final String KEY_CURRENT_EMAIL =
            "currentEmail";

    private DatabaseHelper databaseHelper;
    private SharedPrefManager sharedPrefManager;

    private final List<Note> notes =
            new ArrayList<>();

    private NoteAdapter adapter;

    private String userEmail;

    @Nullable
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater,
            @Nullable ViewGroup container,
            @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.fragment_favorites,
                container,
                false
        );

        databaseHelper =
                new DatabaseHelper(requireContext());

        sharedPrefManager =
                SharedPrefManager.getInstance(
                        requireContext()
                );

        userEmail =
                sharedPrefManager.readString(
                        KEY_CURRENT_EMAIL,
                        ""
                );

        RecyclerView recycler =
                view.findViewById(
                        R.id.recyclerFavoriteNotes
                );

        recycler.setLayoutManager(
                new LinearLayoutManager(
                        requireContext()
                )
        );

        adapter =
                new NoteAdapter(
                        notes,
                        this::toggleFavorite
                );

        recycler.setAdapter(adapter);

        return view;
    }

    @Override
    public void onResume() {

        super.onResume();

        if (databaseHelper != null) {
            loadFavorites();
        }
    }

    private void loadFavorites() {

        if (userEmail.isEmpty()) {
            return;
        }

        notes.clear();

        Cursor cursor =
                databaseHelper.getFavoriteNotes(
                        userEmail
                );

        if (cursor != null) {

            try {

                while (cursor.moveToNext()) {

                    notes.add(
                            new Note(

                                    cursor.getInt(
                                            cursor.getColumnIndexOrThrow(
                                                    DatabaseHelper.COL_NOTE_ID
                                            )
                                    ),

                                    cursor.getString(
                                            cursor.getColumnIndexOrThrow(
                                                    DatabaseHelper.COL_NOTE_USER_EMAIL
                                            )
                                    ),

                                    cursor.getString(
                                            cursor.getColumnIndexOrThrow(
                                                    DatabaseHelper.COL_NOTE_TITLE
                                            )
                                    ),

                                    cursor.getString(
                                            cursor.getColumnIndexOrThrow(
                                                    DatabaseHelper.COL_NOTE_CONTENT
                                            )
                                    ),

                                    cursor.getString(
                                            cursor.getColumnIndexOrThrow(
                                                    DatabaseHelper.COL_NOTE_DATE
                                            )
                                    ),

                                    true,

                                    cursor.getString(
                                            cursor.getColumnIndexOrThrow(
                                                    DatabaseHelper.COL_NOTE_TAGS
                                            )
                                    )
                            )
                    );
                }

            } finally {

                cursor.close();
            }
        }

        adapter.notifyDataSetChanged();
    }

    private void toggleFavorite(
            Note note,
            int position) {

        if (databaseHelper.setFavorite(
                note.getId(),
                userEmail,
                false
        )) {

            notes.remove(position);

            adapter.notifyItemRemoved(
                    position
            );

            Toast.makeText(
                    requireContext(),
                    "Removed from favorites",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}