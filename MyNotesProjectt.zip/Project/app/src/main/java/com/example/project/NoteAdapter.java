package com.example.project;

import android.content.Intent;
import android.graphics.drawable.TransitionDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    public interface OnFavoriteClickListener {
        void onFavoriteClick(Note note, int position);
    }

    private final List<Note> notes;
    private final OnFavoriteClickListener favoriteListener;

    public NoteAdapter(
            List<Note> notes,
            OnFavoriteClickListener favoriteListener
    ) {
        this.notes = notes;
        this.favoriteListener = favoriteListener;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_note, parent, false);

        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(
            @NonNull NoteViewHolder holder,
            int position
    ) {

        Note note = notes.get(position);

        // Title
        holder.tvNoteTitle.setText(note.getTitle());

        // Creation date
        holder.tvNoteDate.setText(note.getCreationDate());

        // Tags
        holder.tvNoteTags.setText(
                note.getTags().isEmpty()
                        ? "No tags"
                        : note.getTags()
        );

        // Favorite transition
        TransitionDrawable transitionDrawable =
                (TransitionDrawable) holder.ivFavorite.getDrawable();

        if (note.isFavorite()) {

            transitionDrawable.startTransition(0);

        } else {

            transitionDrawable.resetTransition();
        }

        // Favorite click
        holder.ivFavorite.setOnClickListener(v -> {


            Animation animation =
                    AnimationUtils.loadAnimation(
                            v.getContext(),
                            R.anim.favorite_scale
                    );

            v.startAnimation(animation);


            if (favoriteListener != null) {

                favoriteListener.onFavoriteClick(
                        note,
                        holder.getBindingAdapterPosition()
                );
            }
        });


        holder.itemView.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            v.getContext(),
                            NoteDetailsActivity.class
                    );

            intent.putExtra(
                    "note_id",
                    note.getId()
            );

            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public static class NoteViewHolder
            extends RecyclerView.ViewHolder {

        TextView tvNoteTitle;
        TextView tvNoteDate;
        TextView tvNoteTags;

        ImageView ivFavorite;

        public NoteViewHolder(
                @NonNull View itemView
        ) {

            super(itemView);

            tvNoteTitle =
                    itemView.findViewById(
                            R.id.tvNoteTitle
                    );

            tvNoteDate =
                    itemView.findViewById(
                            R.id.tvNoteDate
                    );

            tvNoteTags =
                    itemView.findViewById(
                            R.id.tvNoteTags
                    );

            ivFavorite =
                    itemView.findViewById(
                            R.id.ivFavorite
                    );
        }
    }
}